// This component has been removed as per the redesign requirements.
const HowItWorks = () => null;
export default HowItWorks;